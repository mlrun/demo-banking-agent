### 0.2.2

- Fix streaming endpoint routing to support deployments with URL prefixes
- Make LLM libraries (openai, anthropic, vizro-ai) optional dependencies
- Add `example_questions` parameter for predefined prompts popup menu
- Refactor asset loading to use `append_css`/`append_script` (loads after Vizro CSS for proper style overrides)
- Move inline styles to external CSS file with CSS classes
- Move inline JavaScript to external JS file with `window.vizroChatComponent` namespace

### 0.2.1

- Add example code for all available actions in README
- Correct the installation command with optional dependencies

### 0.2.0

- Refactor to use Vizro action system
- Adopt new design

### 0.1.3

- Apply new linting

### 0.1.2

- Fix layout misalignment when adding to a multi-page dashboard

### 0.1.1

- Refactor styles for improved layout and responsiveness
- Fix incorrect error when api key is not provided as environment variable

### 0.1.0

- Initial release
