"""Vizro chat component with action-based architecture."""

from __future__ import annotations

import base64
import json
from typing import Any, Iterator, Literal, Union

import dash
import dash_mantine_components as dmc
import plotly
from dash import Input, Output, Patch, State, callback, clientside_callback, dcc, html, no_update
from dash.exceptions import PreventUpdate
from dash_extensions import SSE
from dash_extensions.streaming import sse_message, sse_options
from dash_iconify import DashIconify
from flask import Response, request
from pydantic import BaseModel, ConfigDict, Field, model_validator

from vizro.actions._abstract_action import _AbstractAction
from vizro.managers import model_manager
from vizro.models import VizroBaseModel
from vizro.models._models_utils import _log_call, make_actions_chain
from vizro.models.types import ActionType

# -------------------- CSS Class Names --------------------
# These correspond to classes defined in static/css/chat.css
CSS_MESSAGE_BUBBLE = "chat-message-bubble"
CSS_USER_MESSAGE = "chat-user-message"
CSS_ASSISTANT_MESSAGE = "chat-assistant-message"
CSS_MESSAGE_WRAPPER = "chat-message-wrapper"
CSS_USER_TEXT = "chat-user-text"
CSS_ROOT = "chat-root"
CSS_HISTORY_SECTION = "chat-history-section"
CSS_HISTORY_CONTAINER = "chat-history-container"
CSS_INPUT_SECTION = "chat-input-section"
CSS_INPUT_INNER = "chat-input-inner"
CSS_LOADING_MESSAGE = "chat-loading-message"
CSS_FILE_PREVIEW = "chat-file-preview"
CSS_DATA_INFO = "chat-data-info"
CSS_BUTTON_ROW = "chat-button-row"
CSS_LEFT_BUTTONS = "chat-left-buttons"
CSS_EXAMPLE_QUESTION_ITEM = "chat-example-question-item"
CSS_EXAMPLE_MENU_DROPDOWN = "chat-example-menu-dropdown"

# Constants still needed for inline styles (e.g., Plotly graph sizing, buttons)
BORDER_RADIUS = "0px"
COLOR_TEXT_SECONDARY = "var(--text-secondary)"
PLOT_WIDTH = "600px"
PLOT_HEIGHT = "400px"

# -------------------- Base Classes --------------------


class _StreamingRequest(BaseModel):
    """Request payload for streaming chat endpoint.

    Args:
        prompt (str): The user's input prompt.
        messages (list[dict[str, Any]]): List of message dicts with 'role' and 'content_json' keys.

    """

    model_config = ConfigDict(extra="allow")

    prompt: str = Field(description="The user's input prompt.")
    messages: list[dict[str, Any]] = Field(description="List of message dicts with 'role' and 'content_json' keys.")


class _BaseChatAction(_AbstractAction):
    """Base class with shared chat functionality for Chat component actions.

    Args:
        parent_id (str): ID of the parent Chat component.
        prompt (str): Reference to the chat input value. Defaults to `"{parent_id}-chat-input.value"`.
        messages (str): Reference to the message store data. Defaults to `"{parent_id}-store.data"`.

    """

    parent_id: str = Field(description="ID of the parent Chat component.")
    prompt: str = Field(
        default_factory=lambda data: f"{data['parent_id']}-chat-input.value",
        description="Reference to the chat input value.",
    )
    messages: str = Field(
        default_factory=lambda data: f"{data['parent_id']}-store.data",
        description="Reference to the message store data.",
    )

    # TODO: This override of _parameters is a workaround to auto-detect Fields that are Dash component
    # references (format: "component-id.property"). Without this, users would need to override `function`
    # just to declare extra params like `uploaded_files` in the signature.
    # Vizro's _AbstractAction._runtime_args only includes Fields that are explicitly named in the
    # function signature. By overriding _parameters to include all Fields with "." in their value,
    # we make them available as **extra_inputs without users needing to touch `function`.
    #
    # This approach may not be the best way to do this. Any suggestions?
    @property
    def _parameters(self) -> set[str]:
        """Override to auto-include all Dash component reference Fields as parameters."""
        params = set(super()._parameters)
        for field_name in self.__class__.model_fields:
            value = getattr(self, field_name, None)
            if isinstance(value, str) and "." in value and self.parent_id in value:
                params.add(field_name)
        return params

    @_log_call
    def pre_build(self):
        if self.parent_id != self._parent_model.id:
            raise ValueError(
                f"{self.__class__.__name__} has parent_id='{self.parent_id}' but is attached to "
                f"Chat component with id='{self._parent_model.id}'. "
                f"These must match. Fix: use parent_id='{self._parent_model.id}'"
            )

        self._setup_chat_callbacks()
        self._setup_loading_indicator()
        self._setup_file_upload_callbacks()

    def _setup_streaming_callbacks(self):
        """SSE streaming decoding and accumulation."""
        # Uses external JS function from static/js/chat.js
        clientside_callback(
            """
            function(animatedText, existingChildren, storeData) {
                return window.vizroChatComponent.processStreamingChunk(animatedText, existingChildren, storeData);
            }
            """,
            [
                Output(f"{self.parent_id}-hidden-messages", "children", allow_duplicate=True),
                Output(f"{self.parent_id}-store", "data", allow_duplicate=True),
            ],
            Input(f"{self.parent_id}-sse", "animation"),
            [State(f"{self.parent_id}-hidden-messages", "children"), State(f"{self.parent_id}-store", "data")],
            prevent_initial_call=True,
        )

    def _setup_chat_callbacks(self):
        """Set up generic chat UI callbacks."""
        # Clientside callback to parse markdown and render code blocks with syntax highlighting
        # Uses external JS function from static/js/chat.js
        clientside_callback(
            """
            function(children) {
                return window.vizroChatComponent.renderMessages(children);
            }
            """,
            Output(f"{self.parent_id}-rendered-messages", "children"),
            Input(f"{self.parent_id}-hidden-messages", "children"),
            prevent_initial_call=True,
        )

        # Handle Enter key for submission (but allow Shift+Enter for new lines)
        # Uses external JS function from static/js/chat.js
        clientside_callback(
            f"""
            function(value) {{
                window.vizroChatComponent.setupEnterKeyHandler('{self.parent_id}');
                return window.dash_clientside.no_update;
            }}
            """,
            Output(f"{self.parent_id}-chat-input", "id", allow_duplicate=True),  # Dummy output
            Input(f"{self.parent_id}-chat-input", "value"),
            prevent_initial_call=True,
        )

        # Horrible hack to restore chat history when you change page and return.
        page = model_manager._get_model_page(self)

        @callback(
            [
                Output(f"{self.parent_id}-hidden-messages", "children", allow_duplicate=True),
                Output(
                    "vizro_version", "children", allow_duplicate=True
                ),  # Extremely horrible hack we should change, just done here to make
                # sure callback triggers (must have prevent_initial_call=True).
                Output(f"{self.parent_id}-data-info", "children", allow_duplicate=True),
            ],
            Input(*page._action_triggers["__default__"].split(".")),
            [
                State(f"{self.parent_id}-store", "data"),
                State(f"{self.parent_id}-file-store", "data"),
            ],
            prevent_initial_call=True,
        )
        def on_page_load(_, store, files):
            html_messages = [self.message_to_html(message) for message in store]
            filenames = [f["filename"] for f in files] if files else []
            file_preview = self._create_file_preview(filenames) if filenames else ""
            return html_messages, dash.no_update, file_preview

    def _setup_file_upload_callbacks(self):
        @callback(
            Output(f"{self.parent_id}-file-store", "data"),
            Output(f"{self.parent_id}-data-info", "children"),
            Input(f"{self.parent_id}-upload", "contents"),
            State(f"{self.parent_id}-upload", "filename"),
            State(f"{self.parent_id}-file-store", "data"),
            prevent_initial_call=True,
        )
        def process_upload(new_contents, new_filenames, existing_files):
            """Store uploaded files."""
            if new_contents is None:
                return no_update, no_update

            if not isinstance(new_contents, list):
                new_contents = [new_contents]
                new_filenames = [new_filenames]

            # Append new files to existing ones
            all_files = existing_files or []
            all_files.extend({"content": c, "filename": f} for c, f in zip(new_contents, new_filenames))

            return all_files, self._create_file_preview([f["filename"] for f in all_files])

        @callback(
            Output(f"{self.parent_id}-file-store", "data", allow_duplicate=True),
            Output(f"{self.parent_id}-data-info", "children", allow_duplicate=True),
            Input({"type": f"{self.parent_id}-remove-file", "index": dash.ALL}, "n_clicks"),
            State(f"{self.parent_id}-file-store", "data"),
            prevent_initial_call=True,
        )
        def remove_file(n_clicks, files):
            """Remove a specific uploaded file by index."""
            if not n_clicks or not any(n_clicks):
                return no_update, no_update

            ctx = dash.callback_context
            if not ctx.triggered:
                return no_update, no_update

            # Get the index of the file to remove
            triggered_id = ctx.triggered[0]["prop_id"].split(".")[0]
            index = json.loads(triggered_id)["index"]

            # Remove the file at the specified index
            if files and 0 <= index < len(files):
                files = files[:index] + files[index + 1 :]
                if not files:
                    return [], ""
                return files, self._create_file_preview([f["filename"] for f in files])

            return no_update, no_update

    def generate_response(self, messages: list[dict[str, Any]], **kwargs: Any) -> Any:
        """Generate a response from the chat model. Must be implemented by subclasses.

        Args:
            messages: List of message dicts with 'role' and 'content_json' keys (content is serialized JSON).
            **kwargs: Additional keyword arguments from extra Fields.

        Returns:
            Response content as string or Dash component.

        Raises:
            NotImplementedError: If not implemented by subclass.

        """
        raise NotImplementedError("Subclasses must implement generate_response()")

    def _create_file_preview(self, filenames: list[str]) -> html.Div:
        """Create file preview UI component for multiple files.

        Args:
            filenames: List of filenames to display.

        Returns:
            Dash HTML Div component with file preview chips.

        """
        file_items = []
        for i, filename in enumerate(filenames):
            file_items.append(
                dmc.Paper(
                    [
                        dmc.Group(
                            [
                                dmc.Text(
                                    filename,
                                    size="sm",
                                    fw=500,
                                    style={"maxWidth": "150px", "overflow": "hidden", "textOverflow": "ellipsis"},
                                ),
                                dmc.ActionIcon(
                                    DashIconify(icon="material-symbols:close", width=16),
                                    size="xs",
                                    variant="subtle",
                                    id={"type": f"{self.parent_id}-remove-file", "index": i},
                                    n_clicks=0,
                                ),
                            ],
                            justify="space-between",
                            style={"width": "100%"},
                        )
                    ],
                    p="xs",
                    radius="sm",
                    withBorder=True,
                    style={"backgroundColor": "var(--surfaces-bg-card)"},
                )
            )

        return html.Div(
            file_items,
            className=CSS_FILE_PREVIEW,
        )

    def message_to_html(self, message: dict[str, str]) -> html.Div:
        """Convert a message dict to HTML structure.

        Override this method for custom rendering logic.

        Args:
            message: Dict with 'role' and 'content_json' keys.

        Returns:
            Dash HTML Div component representing the message.

        """
        role = message["role"]
        content = json.loads(message["content_json"])

        if role == "user":
            return html.Div(
                html.Div(
                    html.Div(str(content) if content else "", className=CSS_USER_TEXT),
                    className=f"{CSS_MESSAGE_BUBBLE} {CSS_USER_MESSAGE}",
                ),
                className=CSS_MESSAGE_WRAPPER,
            )
        # Assistant message
        elif isinstance(content, str):
            # Text: use structure for clientside markdown/code processing
            return html.Div(
                [
                    html.Div("assistant", style={"display": "none"}),  # Hidden role marker
                    html.Div(content),  # Plain text for clientside to process
                ]
            )
        else:
            # Component: render directly with styling
            return html.Div(
                html.Div(content, className=f"{CSS_MESSAGE_BUBBLE} {CSS_ASSISTANT_MESSAGE}"),
                className=CSS_MESSAGE_WRAPPER,
            )

    def _setup_loading_indicator(self):
        """Set up loading indicator using a serverside callback.

        This callback triggers immediately on button click and:
        1. Adds user message and loading placeholder to hidden-messages (UI only)
        2. Clears the input

        Note: This doesn't update the store - that's handled by function().
        The loading placeholder gets replaced when the main action callback returns.
        """

        @callback(
            Output(f"{self.parent_id}-hidden-messages", "children", allow_duplicate=True),
            Output(f"{self.parent_id}-chat-input", "value", allow_duplicate=True),
            Input(f"{self.parent_id}-send-button", "n_clicks"),
            State(f"{self.parent_id}-chat-input", "value"),
            prevent_initial_call=True,
        )
        def update_with_user_input(_, prompt):
            """Handle immediate UI update when user sends a message."""
            if not prompt or not prompt.strip():
                raise PreventUpdate

            html_messages = Patch()

            # Add user message to display
            latest_input = {"role": "user", "content_json": json.dumps(prompt)}
            html_messages.append(self.message_to_html(latest_input))

            # Add a loading indicator as a temporary assistant message
            loading_msg = html.Div(
                html.Div(
                    dmc.Loader(size="sm", type="dots"),
                    className=f"{CSS_MESSAGE_BUBBLE} {CSS_ASSISTANT_MESSAGE} {CSS_LOADING_MESSAGE}",
                ),
                className=CSS_MESSAGE_WRAPPER,
            )
            html_messages.append(loading_msg)

            # Clear input
            return html_messages, ""


class ChatAction(_BaseChatAction):
    """Non-streaming chat action for synchronous response generation.

    Subclass this to create custom chat actions that return complete responses.

    Args:
        type (Literal["chat_action"]): Defaults to `"chat_action"`.
        parent_id (str): ID of the parent Chat component.

    Example:
        ```python
        class my_chat(ChatAction):
            type: Literal["my_chat"] = "my_chat"

            def generate_response(self, messages, **kwargs):
                return "Hello from my chat!"
        ```

    """

    type: Literal["chat_action"] = "chat_action"

    def generate_response(self, messages: list[dict[str, Any]], **kwargs: Any) -> Union[str, html.Div]:
        """Generate a chat response.

        Args:
            messages: List of message dicts with 'role' and 'content_json' keys (content is serialized JSON).
            **kwargs: Extra Field inputs defined on the action.

        Returns:
            Response content as string or Dash component (will be JSON-serialized automatically).

        Raises:
            NotImplementedError: Must be implemented by subclass.

        """
        raise NotImplementedError("Subclasses must implement generate_response()")

    def function(self, prompt: str, messages: list[dict[str, Any]], **extra_inputs: Any) -> list[Any]:
        """Execute the chat action callback.

        Args:
            prompt: User's input text.
            messages: Current message history.
            **extra_inputs: Additional inputs from Fields.

        Returns:
            List of outputs for store, hidden-messages, and chat-input.

        """
        if not prompt or not prompt.strip():
            return [no_update] * len(self.outputs)

        latest_input = {"role": "user", "content_json": json.dumps(prompt)}
        messages.append(latest_input)

        store = Patch()
        store.append(latest_input)

        result = self.generate_response(messages, **extra_inputs)
        # Serialize the result - handles both strings and Dash components
        content_json = json.dumps(result, cls=plotly.utils.PlotlyJSONEncoder)
        latest_output = {"role": "assistant", "content_json": content_json}
        store.append(latest_output)

        html_messages = [self.message_to_html(msg) for msg in messages]
        html_messages.append(self.message_to_html(latest_output))

        return [store, html_messages, no_update]

    @property
    def outputs(self) -> list[str]:
        """Define callback outputs for this action.

        Returns:
            List of output component references.

        """
        return [
            f"{self.parent_id}-store.data",
            f"{self.parent_id}-hidden-messages.children",
            f"{self.parent_id}-chat-input.value",
        ]


class StreamingChatAction(_BaseChatAction):
    """Streaming chat action for real-time response generation via SSE.

    Subclass this to create custom chat actions that stream responses in real-time.

    Args:
        type (Literal["streaming_chat_action"]): Defaults to `"streaming_chat_action"`.
        parent_id (str): ID of the parent Chat component.

    Example:
        ```python
        class my_streaming_chat(StreamingChatAction):
            type: Literal["my_streaming_chat"] = "my_streaming_chat"

            def generate_response(self, messages, **kwargs):
                for chunk in ["Hello", " ", "World!"]:
                    yield chunk
        ```

    """

    type: Literal["streaming_chat_action"] = "streaming_chat_action"

    @_log_call
    def pre_build(self) -> None:
        """Set up streaming callbacks and endpoint during pre-build phase."""
        super().pre_build()
        self._setup_streaming_callbacks()
        self._setup_streaming_endpoint()

    def generate_response(self, messages: list[dict[str, Any]], **kwargs: Any) -> Iterator[str]:
        """Generate a streaming chat response.

        Args:
            messages: List of message dicts with 'role' and 'content_json' keys (content is serialized JSON).
            **kwargs: Extra Field inputs defined on the action.

        Yields:
            Text chunks to stream to the client.

        Raises:
            NotImplementedError: Must be implemented by subclass.

        """
        raise NotImplementedError("Subclasses must implement generate_response()")

    def _setup_streaming_endpoint(self) -> None:
        """Set up streaming endpoint for SSE."""
        CHUNK_DELIMITER = "|END|"
        # Get the base pathname to support deployments with URL prefixes
        base_pathname = dash.get_app().config.requests_pathname_prefix.rstrip("/")

        @dash.get_app().server.route(
            f"{base_pathname}/streaming-{self.parent_id}", methods=["POST"], endpoint=f"streaming_chat_{self.parent_id}"
        )
        def streaming_chat():
            data = request.get_json()
            messages = data.pop("messages")
            data.pop("prompt")  # Not needed for generate_response
            # Remaining data is extra inputs
            extra_inputs = data

            def event_stream():
                for chunk in self.generate_response(messages, **extra_inputs):
                    # Encode chunk as base64 to handle any special characters
                    encoded_chunk = base64.b64encode(chunk.encode("utf-8")).decode("utf-8")
                    # Need a robust delimiter for clientside parsing
                    yield sse_message(encoded_chunk + CHUNK_DELIMITER)

                # Send SSE completion signal
                yield sse_message()

            return Response(event_stream(), mimetype="text/event-stream")

    def function(self, prompt: str, messages: list[dict[str, Any]], **extra_inputs: Any) -> list[Any]:
        """Execute the streaming chat action callback.

        Args:
            prompt: User's input text.
            messages: Current message history.
            **extra_inputs: Additional inputs from Fields.

        Returns:
            List of outputs for store, hidden-messages, chat-input, SSE url, and SSE options.

        """
        if not prompt or not prompt.strip():
            return [no_update] * len(self.outputs)

        latest_input = {"role": "user", "content_json": json.dumps(prompt)}
        messages.append(latest_input)

        store = Patch()
        store.append(latest_input)

        # For streaming: add empty assistant placeholder, then start SSE
        placeholder_msg = {"role": "assistant", "content_json": json.dumps("")}
        store.append(placeholder_msg)

        html_messages = [self.message_to_html(msg) for msg in messages]
        html_messages.append(self.message_to_html(placeholder_msg))

        # Pass all extra inputs through to SSE endpoint
        sse_request = _StreamingRequest(prompt=prompt, messages=messages, **extra_inputs)

        # Get the base pathname to support deployments with URL prefixes (e.g., /cnx/)
        base_pathname = dash.get_app().config.requests_pathname_prefix.rstrip("/")

        return [
            store,
            html_messages,
            no_update,
            f"{base_pathname}/streaming-{self.parent_id}",
            sse_options(sse_request),
        ]

    @property
    def outputs(self) -> list[str]:
        """Define callback outputs for this action.

        Returns:
            List of output component references.

        """
        return [
            f"{self.parent_id}-store.data",
            f"{self.parent_id}-hidden-messages.children",
            f"{self.parent_id}-chat-input.value",
            f"{self.parent_id}-sse.url",
            f"{self.parent_id}-sse.options",
        ]


# -------------------- Chat Component --------------------


class Chat(VizroBaseModel):
    """Chat component for conversational AI interfaces.

    Args:
        type (Literal["chat"]): Defaults to `"chat"`.
        actions (list[ActionType]): List of chat actions to handle responses. Defaults to `[]`.
        placeholder (str): Placeholder text for the input field. Defaults to `"How can I help you?"`.
        file_upload (bool): Enable file upload functionality. Defaults to `False`.
        example_questions (list[str]): List of example questions to show in a popup menu. Defaults to `[]`.

    """

    type: Literal["chat"] = "chat"
    actions: list[ActionType] = Field(default=[], description="List of chat actions to handle responses.")
    placeholder: str = Field(default="How can I help you?", description="Placeholder text for the input field.")
    file_upload: bool = Field(default=False, description="Enable file upload functionality.")
    example_questions: list[str] = Field(default=[], description="List of example questions to show in a popup menu.")

    # This is how you make a new component a trigger of an action in the new system.
    _make_actions_chain = model_validator(mode="after")(make_actions_chain)

    @property
    def _action_triggers(self) -> dict[str, str]:
        """Define action triggers for the chat component.

        Returns:
            Dict mapping trigger names to component property references.

        """
        return {"__default__": f"{self.id}-send-button.n_clicks"}

    @_log_call
    def pre_build(self) -> None:
        """Set up callbacks for example questions during pre-build phase."""
        # Register CSS/JS assets with Dash (loads after Vizro's CSS to allow overrides)
        # Import here to avoid circular import (component.py <-> __init__.py)
        from vizro_chat_component import _register_assets  # noqa: PLC0415

        _register_assets()

        if self.example_questions:
            self._setup_example_questions_callback()

    def _setup_example_questions_callback(self) -> None:
        """Set up callback to fill chat input when example question is clicked."""
        # Store the questions list for use in the callback
        questions = self.example_questions

        @callback(
            Output(f"{self.id}-chat-input", "value", allow_duplicate=True),
            Input({"type": f"{self.id}-example-question", "index": dash.ALL}, "n_clicks"),
            prevent_initial_call=True,
        )
        def fill_example_question(n_clicks):
            """Fill chat input with the clicked example question."""
            if not n_clicks or not any(n_clicks):
                raise PreventUpdate

            ctx = dash.callback_context
            if not ctx.triggered:
                raise PreventUpdate

            # Get the index of the clicked question
            triggered_id = ctx.triggered[0]["prop_id"].split(".")[0]
            index = json.loads(triggered_id)["index"]

            if 0 <= index < len(questions):
                return questions[index]

            raise PreventUpdate

    def _build_upload_stores(self) -> list[dcc.Store]:
        """Build stores for file upload.

        Returns:
            List of dcc.Store components for file upload state.

        """
        return [dcc.Store(id=f"{self.id}-file-store", storage_type="session")]

    def _build_example_questions_menu(self) -> dmc.Menu:
        """Build the example questions popup menu.

        Returns:
            Dash Mantine Menu component with example questions.

        """
        menu_items = [
            dmc.MenuItem(
                question,
                id={"type": f"{self.id}-example-question", "index": i},
                className=CSS_EXAMPLE_QUESTION_ITEM,
            )
            for i, question in enumerate(self.example_questions)
        ]

        return dmc.Menu(
            [
                dmc.MenuTarget(
                    dmc.ActionIcon(
                        [
                            DashIconify(icon="material-symbols-light:chat-outline-sharp", width=24, height=24),
                            DashIconify(icon="material-symbols:keyboard-arrow-up", width=16, height=16),
                        ],
                        variant="subtle",
                        color="grey",
                        radius=BORDER_RADIUS,
                        style={"width": "52px", "height": "42px"},
                        id=f"{self.id}-example-questions-button",
                    )
                ),
                dmc.MenuDropdown(
                    menu_items,
                    className=CSS_EXAMPLE_MENU_DROPDOWN,
                ),
            ],
            position="top-start",
            shadow="md",
        )

    def _build_input_area(self) -> html.Div:
        """Build the input area with optional file upload button.

        Returns:
            Dash HTML Div containing the input area components.

        """
        # File upload button
        upload_button = dcc.Upload(
            id=f"{self.id}-upload",
            children=dmc.ActionIcon(
                DashIconify(icon="material-symbols-light:attach-file-add", width=28, height=28),
                variant="subtle",
                color="grey",
                radius=BORDER_RADIUS,
                style={"width": "42px", "height": "42px"},
            ),
            style={"width": "fit-content", "display": "block" if self.file_upload else "none"},
            multiple=True,
        )

        # Example questions menu button
        example_questions_menu = (
            self._build_example_questions_menu() if self.example_questions else html.Div(style={"display": "none"})
        )

        # Build children list explicitly
        inner_children = []

        inner_children.append(html.Div(id=f"{self.id}-data-info", className=CSS_DATA_INFO))

        # Textarea - Mantine components need inline styles for internal styling
        inner_children.append(
            dmc.Textarea(
                id=f"{self.id}-chat-input",
                placeholder=self.placeholder,
                autosize=True,
                size="md",
                minRows=1,
                maxRows=6,
                radius=0,
                styles={
                    "input": {
                        "borderLeft": "none",
                        "borderRight": "none",
                        "borderTop": "none",
                        "borderRadius": "0",
                        "resize": "none",
                        "backgroundColor": "var(--bs-body-bg)",
                        "fontSize": "var(--chat-font-size)",
                        "lineHeight": "var(--chat-line-height)",
                        "color": "var(--text-primary)",
                    }
                },
                style={"width": "100%"},
                value="",
            )
        )

        # Left buttons group (file upload + example questions)
        left_buttons = html.Div(
            [upload_button, example_questions_menu],
            className=CSS_LEFT_BUTTONS,
        )

        # Button row
        inner_children.append(
            html.Div(
                [
                    left_buttons,
                    dmc.ActionIcon(
                        DashIconify(icon="material-symbols-light:send-outline", width=38, height=38),
                        id=f"{self.id}-send-button",
                        variant="subtle",
                        color="grey",
                        n_clicks=0,
                        radius=BORDER_RADIUS,
                        style={"width": "42px", "height": "42px"},
                    ),
                ],
                className=CSS_BUTTON_ROW,
            )
        )

        return html.Div(
            [
                html.Div(
                    inner_children,
                    className=CSS_INPUT_INNER,
                )
            ],
            className=CSS_INPUT_SECTION,
        )

    @_log_call
    def build(self) -> html.Div:
        """Build the chat component layout.

        Returns:
            Dash HTML Div containing the complete chat interface.

        """
        return html.Div(
            [
                *self._build_upload_stores(),
                # Messages container
                html.Div(
                    [
                        html.Div(
                            [
                                html.Div(id=f"{self.id}-hidden-messages", children=[], style={"display": "none"}),
                                html.Div(id=f"{self.id}-rendered-messages", className=CSS_HISTORY_CONTAINER),
                            ],
                            id=f"{self.id}-chat-messages-container",
                        )
                    ],
                    className=CSS_HISTORY_SECTION,
                ),
                # Input area
                self._build_input_area(),
                # Store for conversation history
                dcc.Store(id=f"{self.id}-store", data=[], storage_type="session"),
                # Server-Sent Events for streaming support
                SSE(id=f"{self.id}-sse", concat=True, animate_chunk=10, animate_delay=5),
            ],
            className=CSS_ROOT,
        )
