"""Example chat action implementations for the Vizro Chat component."""

from __future__ import annotations

import base64
import io
import json
from typing import Any, Iterator, Literal

import dash_mantine_components as dmc
import pandas as pd
from dash import dcc, html
from pydantic import Field

import vizro.plotly.express as px

# Optional dependencies - only imported when needed
try:
    from openai import OpenAI
except ImportError:
    OpenAI = None  # type: ignore[assignment, misc]

try:
    from anthropic import Anthropic
except ImportError:
    Anthropic = None  # type: ignore[assignment, misc]

try:
    from vizro_ai import VizroAI
except ImportError:
    VizroAI = None  # type: ignore[assignment, misc]

from vizro_chat_component.component import (
    COLOR_TEXT_SECONDARY,
    PLOT_HEIGHT,
    PLOT_WIDTH,
    ChatAction,
    StreamingChatAction,
)


class simple_echo(ChatAction):
    """Simple echo chat that returns the user's message.

    Args:
        type (Literal["simple_echo"]): Defaults to `"simple_echo"`.
        parent_id (str): ID of the parent Chat component.

    """

    type: Literal["simple_echo"] = "simple_echo"

    def generate_response(self, messages: list[dict[str, Any]]) -> str:
        """Echo the user's last message.

        Args:
            messages: List of message dicts with 'role' and 'content_json' keys.

        Returns:
            Echo of the user's last message.

        """
        last_message = json.loads(messages[-1]["content_json"]) if messages else ""
        return f"You said: {last_message}"


class openai_chat(ChatAction):
    """OpenAI non-streaming chat implementation.

    Args:
        type (Literal["openai_chat"]): Defaults to `"openai_chat"`.
        parent_id (str): ID of the parent Chat component.
        model (str): OpenAI model name. Defaults to `"gpt-4.1-nano"`.

    """

    type: Literal["openai_chat"] = "openai_chat"
    model: str = Field(default="gpt-4.1-nano", description="OpenAI model name.")

    @property
    def client(self):  # noqa: D102
        if OpenAI is None:
            raise ImportError("OpenAI package not installed. Install with: pip install openai")
        return OpenAI()

    def generate_response(self, messages: list[dict[str, Any]]) -> str:
        """Generate response from OpenAI.

        Args:
            messages: List of message dicts with 'role' and 'content_json' keys.

        Returns:
            Generated text response.

        """
        api_messages = [{"role": msg["role"], "content": json.loads(msg["content_json"])} for msg in messages]
        response = self.client.responses.create(
            model=self.model,
            input=api_messages,
            instructions="Be polite and creative.",
            store=False,
        )
        return response.output_text


class openai_streaming_chat(StreamingChatAction):
    """OpenAI streaming chat implementation.

    Args:
        type (Literal["openai_streaming_chat"]): Defaults to `"openai_streaming_chat"`.
        parent_id (str): ID of the parent Chat component.
        model (str): OpenAI model name. Defaults to `"gpt-4.1-nano"`.

    """

    type: Literal["openai_streaming_chat"] = "openai_streaming_chat"
    model: str = Field(default="gpt-4.1-nano", description="OpenAI model name.")

    @property
    def client(self):  # noqa: D102
        if OpenAI is None:
            raise ImportError("OpenAI package not installed. Install with: pip install openai")
        return OpenAI()

    def generate_response(self, messages: list[dict[str, Any]]) -> Iterator[str]:
        """Generate streaming response from OpenAI.

        Args:
            messages: List of message dicts with 'role' and 'content_json' keys.

        Yields:
            Text chunks from OpenAI's response.

        """
        api_messages = [{"role": msg["role"], "content": json.loads(msg["content_json"])} for msg in messages]
        response = self.client.responses.create(
            model=self.model,
            input=api_messages,
            instructions="Be polite and creative.",
            store=False,
            stream=True,
        )

        for event in response:
            if event.type == "response.output_text.delta":
                yield event.delta


class anthropic_chat(StreamingChatAction):
    """Streaming implementation for Anthropic Claude chat.

    Args:
        type (Literal["anthropic_chat"]): Defaults to `"anthropic_chat"`.
        parent_id (str): ID of the parent Chat component.
        model (str): Anthropic model name. Defaults to `"claude-haiku-4-5-20251001"`.

    """

    type: Literal["anthropic_chat"] = "anthropic_chat"
    model: str = Field(default="claude-haiku-4-5-20251001", description="Anthropic model name.")

    def generate_response(self, messages: list[dict[str, Any]]) -> Iterator[str]:
        """Generate streaming response from Anthropic Claude.

        Args:
            messages: List of message dicts with 'role' and 'content_json' keys.

        Yields:
            Text chunks from Claude's response.

        """
        if Anthropic is None:
            raise ImportError("Anthropic package not installed. Install with: pip install anthropic")
        client = Anthropic()
        api_messages = [{"role": msg["role"], "content": json.loads(msg["content_json"])} for msg in messages]
        with client.messages.stream(
            model=self.model,
            max_tokens=1024,
            messages=api_messages,
        ) as stream:
            for text in stream.text_stream:
                yield text


class mixed_content(ChatAction):
    """Example showing different content types: text, chart, and image.

    Args:
        type (Literal["mixed_content"]): Defaults to `"mixed_content"`.
        parent_id (str): ID of the parent Chat component.

    """

    type: Literal["mixed_content"] = "mixed_content"

    def generate_response(self, messages: list[dict[str, Any]]) -> html.Div:
        """Generate a response with mixed content types.

        Args:
            messages: List of message dicts with 'role' and 'content_json' keys.

        Returns:
            Dash HTML Div containing various Dash components to showcase rendering capabilities.

        """
        prompt = json.loads(messages[-1]["content_json"]) if messages else ""

        # Sample data for table
        table_data = [
            {"feature": "Streaming", "status": "Supported", "description": "Real-time text generation"},
            {"feature": "File Upload", "status": "Supported", "description": "Images, CSV, Excel files"},
            {"feature": "Code Highlight", "status": "Supported", "description": "Syntax highlighting"},
        ]

        # Create a scatter plot
        fig = px.scatter(
            px.data.iris(),
            x="sepal_width",
            y="sepal_length",
            color="species",
            title="Interactive Plotly Chart",
        )

        # Sample code for CodeHighlight
        sample_code = '''def generate_response(self, messages):
    """Your custom chat logic here."""
    return "Hello, World!"'''

        return html.Div(
            [
                # Introduction
                dcc.Markdown(f'**You said:** "{prompt}"'),
                dmc.Alert(
                    "This demo showcases various Dash components that can be rendered in chat responses!",
                    title="Component Showcase",
                    color="blue",
                    style={"marginTop": "15px", "marginBottom": "15px"},
                ),
                dmc.Table(
                    striped=True,
                    highlightOnHover=True,
                    withTableBorder=True,
                    withColumnBorders=True,
                    data={
                        "head": ["Feature", "Status", "Description"],
                        "body": [[row["feature"], row["status"], row["description"]] for row in table_data],
                    },
                    style={"marginBottom": "15px"},
                ),
                # Accordion with expandable sections
                dmc.Accordion(
                    children=[
                        dmc.AccordionItem(
                            value="chart",
                            children=[
                                dmc.AccordionControl("Interactive Chart"),
                                dmc.AccordionPanel(
                                    dcc.Graph(figure=fig, style={"height": PLOT_HEIGHT, "width": PLOT_WIDTH})
                                ),
                            ],
                        ),
                        dmc.AccordionItem(
                            value="code",
                            children=[
                                dmc.AccordionControl("Code Example"),
                                dmc.AccordionPanel(
                                    dmc.CodeHighlight(code=sample_code, language="python", withCopyButton=True)
                                ),
                            ],
                        ),
                        dmc.AccordionItem(
                            value="image",
                            children=[
                                dmc.AccordionControl("Image"),
                                dmc.AccordionPanel(
                                    dmc.Image(
                                        radius="md",
                                        h=200,
                                        w="auto",
                                        fit="contain",
                                        src="https://raw.githubusercontent.com/mantinedev/mantine/master/.demo/images/bg-9.png",
                                    )
                                ),
                            ],
                        ),
                    ],
                    style={"marginBottom": "15px"},
                ),
                # Blockquote
                dmc.Blockquote(
                    "Any Dash component can be rendered in chat responses!",
                    cite="- Vizro Chat Component",
                    color="blue",
                    style={"marginBottom": "15px"},
                ),
            ]
        )


class vizro_ai_chat(ChatAction):
    """Generate data visualizations using natural language with VizroAI.

    Args:
        type (Literal["vizro_ai_chat"]): Defaults to `"vizro_ai_chat"`.
        parent_id (str): ID of the parent Chat component.
        uploaded_files (str): Reference to file store data. Defaults to `"{parent_id}-file-store.data"`.

    """

    type: Literal["vizro_ai_chat"] = "vizro_ai_chat"
    uploaded_files: str = Field(
        default_factory=lambda data: f"{data['parent_id']}-file-store.data",
        description="Reference to file store data.",
    )

    def generate_response(
        self,
        messages: list[dict[str, Any]],
        uploaded_files: list[dict[str, str]] | None = None,
    ) -> html.Div | html.P:
        """Generate data visualization using VizroAI.

        Args:
            messages: List of message dicts with 'role' and 'content_json' keys.
            uploaded_files: List of uploaded file dicts with 'content' and 'filename' keys.

        Returns:
            Dash component containing the generated visualization or error message.

        """
        if VizroAI is None:
            return html.P(
                "VizroAI not installed. Install with: pip install vizro-ai",
                style={"color": "red"},
            )

        prompt = json.loads(messages[-1]["content_json"]) if messages else ""

        if not uploaded_files:
            return html.P("Please upload a data file first!", style={"color": "#1890ff"})

        # Get the first uploaded file
        uploaded_data = uploaded_files[0]["content"]
        uploaded_filename = uploaded_files[0]["filename"]

        # Parse the raw file contents (base64 encoded from dcc.Upload)
        try:
            _content_type, content_string = uploaded_data.split(",")
            decoded = base64.b64decode(content_string)

            if uploaded_filename and uploaded_filename.endswith(".csv"):
                df = pd.read_csv(io.BytesIO(decoded))
            elif uploaded_filename and uploaded_filename.endswith((".xls", ".xlsx")):
                df = pd.read_excel(io.BytesIO(decoded))
            else:
                return html.P(
                    f"Unsupported file type: {uploaded_filename}. Please upload CSV or Excel files.",
                    style={"color": "red"},
                )
        except Exception as e:
            return html.P(f"Error parsing file: {e!s}", style={"color": "red"})

        # Generate plot with VizroAI
        try:
            vizro_ai = VizroAI()
            ai_outputs = vizro_ai.plot(df, prompt, return_elements=True)
            figure = ai_outputs.get_fig_object(data_frame=df, vizro=False)

            return html.Div(
                [
                    dcc.Graph(figure=figure, style={"height": PLOT_HEIGHT, "width": PLOT_WIDTH}),
                    html.Details(
                        [
                            html.Summary(
                                "View generated code", style={"cursor": "pointer", "color": COLOR_TEXT_SECONDARY}
                            ),
                            dmc.CodeHighlight(
                                code=ai_outputs.code,
                                language="python",
                                withCopyButton=True,
                            ),
                        ],
                        style={"marginTop": "10px", "width": PLOT_WIDTH},
                    ),
                ],
                style={"width": PLOT_WIDTH},
            )

        except Exception as e:
            return html.P(f"Error generating visualization: {e!s}", style={"color": "red"})


class openai_vision_chat(ChatAction):
    """OpenAI Vision chat for analyzing images with text prompts.

    Uses the OpenAI responses API with input_image content type for vision capabilities.
    Supports multiple image uploads with a text prompt.

    Args:
        type (Literal["openai_vision_chat"]): Defaults to `"openai_vision_chat"`.
        parent_id (str): ID of the parent Chat component.
        model (str): OpenAI model name. Defaults to `"gpt-4.1-nano"`.
        uploaded_files (str): Reference to file store data. Defaults to `"{parent_id}-file-store.data"`.

    """

    type: Literal["openai_vision_chat"] = "openai_vision_chat"
    model: str = Field(default="gpt-4.1-nano", description="OpenAI model name.")
    uploaded_files: str = Field(
        default_factory=lambda data: f"{data['parent_id']}-file-store.data",
        description="Reference to file store data.",
    )

    @property
    def client(self) -> "OpenAI":
        """Get OpenAI client instance.

        Returns:
            OpenAI client.

        """
        if OpenAI is None:
            raise ImportError("OpenAI package not installed. Install with: pip install openai")
        return OpenAI()

    def generate_response(
        self,
        messages: list[dict[str, Any]],
        uploaded_files: list[dict[str, str]] | None = None,
    ) -> str | html.P:
        """Generate response using OpenAI Vision API with images.

        Args:
            messages: List of message dicts with 'role' and 'content_json' keys.
            uploaded_files: List of uploaded file dicts with 'content' and 'filename' keys.

        Returns:
            Generated text response or error message component.

        """
        prompt = json.loads(messages[-1]["content_json"]) if messages else ""

        content = [{"type": "input_text", "text": prompt}]

        if uploaded_files:
            for file_info in uploaded_files:
                data = file_info["content"]
                filename = file_info["filename"]

                # supported image file types: https://platform.openai.com/docs/guides/images-vision#analyze-images
                is_image = any(filename.lower().endswith(ext) for ext in [".png", ".jpg", ".jpeg", ".gif", ".webp"])

                if is_image:
                    # data is already base64 encoded from dcc.Upload (format: "data:image/png;base64,...")
                    content.append(
                        {
                            "type": "input_image",
                            "image_url": data,  # Pass the full data URL
                        }
                    )

        # Build API messages
        api_messages = []
        for msg in messages[:-1]:  # Exclude the last message since we'll add it with images
            api_messages.append({"role": msg["role"], "content": json.loads(msg["content_json"])})

        # Add the current message with images
        api_messages.append({"role": "user", "content": content})

        try:
            response = self.client.responses.create(
                model=self.model,
                input=api_messages,
                instructions="You are a helpful assistant that can analyze images and answer questions about them.",
                store=False,
            )
            return response.output_text

        except Exception as e:
            return html.P(f"Error calling OpenAI Vision API: {e!s}", style={"color": "red"})


class openai_vision_streaming_chat(StreamingChatAction):
    """OpenAI Vision chat with streaming for analyzing images with text prompts.

    Uses the OpenAI responses API with input_image content type and streaming.
    Supports multiple image uploads with a text prompt.

    Args:
        type (Literal["openai_vision_streaming_chat"]): Defaults to `"openai_vision_streaming_chat"`.
        parent_id (str): ID of the parent Chat component.
        model (str): OpenAI model name. Defaults to `"gpt-4.1-nano"`.
        uploaded_files (str): Reference to file store data. Defaults to `"{parent_id}-file-store.data"`.

    """

    type: Literal["openai_vision_streaming_chat"] = "openai_vision_streaming_chat"
    model: str = Field(default="gpt-4.1-nano", description="OpenAI model name.")
    uploaded_files: str = Field(
        default_factory=lambda data: f"{data['parent_id']}-file-store.data",
        description="Reference to file store data.",
    )

    @property
    def client(self) -> "OpenAI":
        """Get OpenAI client instance.

        Returns:
            OpenAI client.

        """
        if OpenAI is None:
            raise ImportError("OpenAI package not installed. Install with: pip install openai")
        return OpenAI()

    def generate_response(
        self,
        messages: list[dict[str, Any]],
        uploaded_files: list[dict[str, str]] | None = None,
    ) -> Iterator[str]:
        """Generate streaming response using OpenAI Vision API with images.

        Args:
            messages: List of message dicts with 'role' and 'content_json' keys.
            uploaded_files: List of uploaded file dicts with 'content' and 'filename' keys.

        Yields:
            Text chunks from the streaming response.

        """
        prompt = json.loads(messages[-1]["content_json"]) if messages else ""

        content = [{"type": "input_text", "text": prompt}]

        if uploaded_files:
            for file_info in uploaded_files:
                data = file_info["content"]
                filename = file_info["filename"]

                is_image = any(filename.lower().endswith(ext) for ext in [".png", ".jpg", ".jpeg", ".gif", ".webp"])

                if is_image:
                    content.append(
                        {
                            "type": "input_image",
                            "image_url": data,
                        }
                    )

        # Build API messages
        api_messages = []
        for msg in messages[:-1]:
            api_messages.append({"role": msg["role"], "content": json.loads(msg["content_json"])})

        api_messages.append({"role": "user", "content": content})

        try:
            response = self.client.responses.create(
                model=self.model,
                input=api_messages,
                instructions="You are a helpful assistant that can analyze images and answer questions about them.",
                store=False,
                stream=True,
            )

            for event in response:
                if event.type == "response.output_text.delta":
                    yield event.delta

        except Exception as e:
            yield f"Error calling OpenAI Vision API: {e!s}"
