# Vizro Chat Component

> **Beta:** This component is currently in beta and the API is subject to change.

A custom Vizro component providing chat interface with action-based architecture.

![example1](./images/example1.gif)

## Features

- Support for text streaming responses via Server-Sent Events (SSE)
- Support for any Dash component rendering
- Seamlessly integrate chat functionality into Vizro dashboards
- Action-based architecture with `ChatAction` and `StreamingChatAction` base classes
- Built-in examples for OpenAI, Anthropic Claude, VizroAI, and more
- File upload support for inputs in addition to text input
- Example questions menu for predefined prompts
- Markdown rendering with syntax-highlighted code blocks

## Installation

```bash
pip install brix.vizro_chat_component
```

For running the examples with all features:

```bash
pip install "brix.vizro_chat_component[examples]"
```

## Usage

### Minimal Example

Here's a minimal example using the simple echo action (no API key required):

```python
from typing import Annotated

from pydantic import Tag

import vizro.models as vm
from vizro import Vizro
from vizro_chat_component import Chat, simple_echo

# Register the Chat component with Vizro
vm.Page.add_type("components", Chat)
Chat.add_type("actions", Annotated[simple_echo, Tag("simple_echo")])

page = vm.Page(
    title="Chat Demo",
    components=[
        Chat(
            id="my_chat",
            actions=[simple_echo(parent_id="my_chat")],
        ),
    ],
)

dashboard = vm.Dashboard(pages=[page])
Vizro().build(dashboard).run()
```

### Chat Component API

The `Chat` component accepts the following parameters:

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `id` | `str` | Required | Unique identifier for the chat component |
| `actions` | `list[ActionType]` | `[]` | List of chat actions to handle responses |
| `placeholder` | `str` | `"How can I help you?"` | Placeholder text for the input field |
| `file_upload` | `bool` | `False` | Enable file upload functionality |
| `example_questions` | `list[str]` | `[]` | List of example questions to show in a popup menu |

### Creating Custom Actions

To create your own custom chat actions, inherit from `ChatAction` (non-streaming) or `StreamingChatAction` (streaming) and override the `generate_response` method:

- **`ChatAction`**: Override `generate_response(messages, **kwargs) -> str | html.Div` to return a complete response
- **`StreamingChatAction`**: Override `generate_response(messages, **kwargs) -> Iterator[str]` to yield text chunks

The `messages` parameter is a list of dicts with `role` and `content_json` keys. Use `json.loads(msg["content_json"])` to get the content.

For file upload support, add an `uploaded_files` field that references the file store:

```python
uploaded_files: str = Field(default_factory=lambda data: f"{data['parent_id']}-file-store.data")
```

See the [Available Action Examples](#available-action-examples) for reference implementations.

### OpenAI Streaming Chat

For streaming chat with OpenAI:

```python
from typing import Annotated

from dotenv import load_dotenv
from pydantic import Tag

import vizro.models as vm
from vizro import Vizro
from vizro_chat_component import Chat, openai_streaming_chat

load_dotenv()  # Load OPENAI_API_KEY from .env file

vm.Page.add_type("components", Chat)
Chat.add_type("actions", Annotated[openai_streaming_chat, Tag("openai_streaming_chat")])

page = vm.Page(
    title="OpenAI Chat",
    components=[
        Chat(
            id="chat",
            actions=[openai_streaming_chat(parent_id="chat")],
        ),
    ],
)

dashboard = vm.Dashboard(pages=[page])
Vizro().build(dashboard).run()
```

### Anthropic Claude Chat

For streaming chat with Anthropic Claude:

```python
from typing import Annotated

from dotenv import load_dotenv
from pydantic import Tag

import vizro.models as vm
from vizro import Vizro
from vizro_chat_component import Chat, anthropic_chat

load_dotenv()  # Load ANTHROPIC_API_KEY from .env file

vm.Page.add_type("components", Chat)
Chat.add_type("actions", Annotated[anthropic_chat, Tag("anthropic_chat")])

page = vm.Page(
    title="Claude Chat",
    components=[
        Chat(
            id="claude_chat",
            actions=[anthropic_chat(parent_id="claude_chat")],
        ),
    ],
)

dashboard = vm.Dashboard(pages=[page])
Vizro().build(dashboard).run()
```

### OpenAI Chat (Non-Streaming)

For non-streaming chat with OpenAI (response appears all at once):

```python
from typing import Annotated

from dotenv import load_dotenv
from pydantic import Tag

import vizro.models as vm
from vizro import Vizro
from vizro_chat_component import Chat, openai_chat

load_dotenv()  # Load OPENAI_API_KEY from .env file

vm.Page.add_type("components", Chat)
Chat.add_type("actions", Annotated[openai_chat, Tag("openai_chat")])

page = vm.Page(
    title="OpenAI Chat",
    components=[
        Chat(
            id="chat",
            actions=[openai_chat(parent_id="chat")],
        ),
    ],
)

dashboard = vm.Dashboard(pages=[page])
Vizro().build(dashboard).run()
```

### Mixed Content Demo

Showcase of rendering various Dash components in chat responses (no API key required):

```python
from typing import Annotated

from pydantic import Tag

import vizro.models as vm
from vizro import Vizro
from vizro_chat_component import Chat, mixed_content

vm.Page.add_type("components", Chat)
Chat.add_type("actions", Annotated[mixed_content, Tag("mixed_content")])

page = vm.Page(
    title="Mixed Content Demo",
    components=[
        Chat(
            id="mixed_chat",
            actions=[mixed_content(parent_id="mixed_chat")],
        ),
    ],
)

dashboard = vm.Dashboard(pages=[page])
Vizro().build(dashboard).run()
```

### VizroAI Chart Generation

Generate charts from natural language descriptions with file upload:

```python
from typing import Annotated

from dotenv import load_dotenv
from pydantic import Tag

import vizro.models as vm
from vizro import Vizro
from vizro_chat_component import Chat, vizro_ai_chat

load_dotenv()  # Load OPENAI_API_KEY from .env file

vm.Page.add_type("components", Chat)
Chat.add_type("actions", Annotated[vizro_ai_chat, Tag("vizro_ai_chat")])

page = vm.Page(
    title="VizroAI Chat",
    components=[
        Chat(
            id="vizro_ai_chat",
            file_upload=True,  # Enable file upload for CSV/Excel
            placeholder="Upload a data file and describe the chart you want...",
            actions=[vizro_ai_chat(parent_id="vizro_ai_chat")],
        ),
    ],
)

dashboard = vm.Dashboard(pages=[page])
Vizro().build(dashboard).run()
```

### Vision Chat with File Upload (Streaming)

For image analysis with OpenAI Vision and streaming responses:

```python
from typing import Annotated

from dotenv import load_dotenv
from pydantic import Tag

import vizro.models as vm
from vizro import Vizro
from vizro_chat_component import Chat, openai_vision_streaming_chat

load_dotenv()  # Load OPENAI_API_KEY from .env file

vm.Page.add_type("components", Chat)
Chat.add_type("actions", Annotated[openai_vision_streaming_chat, Tag("openai_vision_streaming_chat")])

page = vm.Page(
    title="Vision Chat",
    components=[
        Chat(
            id="vision_chat",
            file_upload=True,  # Enable file upload
            placeholder="Upload images and ask questions...",
            actions=[openai_vision_streaming_chat(parent_id="vision_chat")],
        ),
    ],
)

dashboard = vm.Dashboard(pages=[page])
Vizro().build(dashboard).run()
```

### Vision Chat (Non-Streaming)

For image analysis with OpenAI Vision without streaming:

```python
from typing import Annotated

from dotenv import load_dotenv
from pydantic import Tag

import vizro.models as vm
from vizro import Vizro
from vizro_chat_component import Chat, openai_vision_chat

load_dotenv()  # Load OPENAI_API_KEY from .env file

vm.Page.add_type("components", Chat)
Chat.add_type("actions", Annotated[openai_vision_chat, Tag("openai_vision_chat")])

page = vm.Page(
    title="Vision Chat",
    components=[
        Chat(
            id="vision_chat",
            file_upload=True,  # Enable file upload
            placeholder="Upload images and ask questions...",
            actions=[openai_vision_chat(parent_id="vision_chat")],
        ),
    ],
)

dashboard = vm.Dashboard(pages=[page])
Vizro().build(dashboard).run()
```

### Example Questions Menu

Add predefined example questions that users can select from a popup menu:

```python
from typing import Annotated

from dotenv import load_dotenv
from pydantic import Tag

import vizro.models as vm
from vizro import Vizro
from vizro_chat_component import Chat, openai_streaming_chat

load_dotenv()

vm.Page.add_type("components", Chat)
Chat.add_type("actions", Annotated[openai_streaming_chat, Tag("openai_streaming_chat")])

page = vm.Page(
    title="Chat with Examples",
    components=[
        Chat(
            id="chat",
            actions=[openai_streaming_chat(parent_id="chat")],
            example_questions=[
                "What is the capital of France?",
                "Explain quantum computing in simple terms",
                "Write a haiku about programming",
            ],
        ),
    ],
)

dashboard = vm.Dashboard(pages=[page])
Vizro().build(dashboard).run()
```

You can also combine `example_questions` with `file_upload`:

```python
Chat(
    id="vizro_ai_chat",
    file_upload=True,
    example_questions=[
        "Show a bar chart of the data",
        "Create a scatter plot of price vs quantity",
        "Make a pie chart showing distribution",
    ],
    actions=[vizro_ai_chat(parent_id="vizro_ai_chat")],
)
```

When both are enabled, buttons appear in order: file upload (left), example questions (middle), send (right).

## Available Action Examples

| Action | Description | Streaming | File Upload |
|--------|-------------|-----------|-------------|
| `simple_echo` | Echoes back user messages | No | No |
| `openai_chat` | OpenAI chat completion | No | No |
| `openai_streaming_chat` | OpenAI with streaming | Yes | No |
| `anthropic_chat` | Anthropic Claude with streaming | Yes | No |
| `mixed_content` | Dash Component rendering showcase (fixed response) | No | No |
| `vizro_ai_chat` | VizroAI chart generation | No | Yes |
| `openai_vision_chat` | OpenAI Vision for image analysis | No | Yes |
| `openai_vision_streaming_chat` | OpenAI Vision with streaming | Yes | Yes |
