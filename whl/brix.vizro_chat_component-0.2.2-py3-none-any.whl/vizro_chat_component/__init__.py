"""Vizro Chat Component - A chat component for Vizro dashboards with action-based architecture."""

from importlib.metadata import version
from pathlib import Path

import dash

# Required by Dash when serving resources with namespace "vizro_chat_component"
__version__ = version("brix.vizro_chat_component")

_STATIC_PATH = Path(__file__).parent / "static"

# Track whether assets have been registered to avoid duplicates
_state = {"assets_registered": False}


def _register_assets():
    """Register CSS and JS assets with Dash app.

    This uses append_css/append_script so assets load AFTER Vizro's CSS (position #3),
    allowing our styles to override Vizro defaults.

    Should be called from Chat.pre_build() after Vizro() has been instantiated.
    """
    if _state["assets_registered"]:
        return

    app = dash.get_app()

    # Register CSS files - sorted to ensure consistent order
    for css_file in sorted(_STATIC_PATH.glob("css/*.css")):
        app.css.append_css(
            {
                "namespace": "vizro_chat_component",
                "relative_package_path": f"static/css/{css_file.name}",
            }
        )

    # Register JS files - sorted to ensure consistent order
    for js_file in sorted(_STATIC_PATH.glob("js/*.js")):
        app.scripts.append_script(
            {
                "namespace": "vizro_chat_component",
                "relative_package_path": f"static/js/{js_file.name}",
            }
        )

    _state["assets_registered"] = True


from vizro_chat_component.actions import (
    anthropic_chat,
    mixed_content,
    openai_chat,
    openai_streaming_chat,
    openai_vision_chat,
    openai_vision_streaming_chat,
    simple_echo,
    vizro_ai_chat,
)
from vizro_chat_component.component import (
    Chat,
    ChatAction,
    StreamingChatAction,
    _BaseChatAction,
)

__all__ = [
    "Chat",
    "ChatAction",
    "StreamingChatAction",
    "_BaseChatAction",
    "anthropic_chat",
    "mixed_content",
    "openai_chat",
    "openai_streaming_chat",
    "openai_vision_chat",
    "openai_vision_streaming_chat",
    "simple_echo",
    "vizro_ai_chat",
]
